<?php
session_start();
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=id21583462_location_materiel;charset=utf8',
        'id21583462_aleszek',
        'bTdwLjdDyTGL$9' 
    );  
    $db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e){
    die('Erreur'.$e->getMessage());
    
}